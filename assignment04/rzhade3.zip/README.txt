# README

For this project, I used Juan Jose's boiler plate code, as found here: https://github.com/juanjose49/omscs-cs7641-machine-learning-assignment-4. For some of the problems, I tried using CMU's RL simulator, however, I only used this to verify convergence in some situations.

I only made minor adjustments to this code, in the way of parameter adjustments, map changes, and added functions, however, I described them in the paper, and so I will not reattach my modified code, since changes were trivial.